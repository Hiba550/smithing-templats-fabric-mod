package com.example;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import java.util.HashMap;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class ExampleModClient implements ClientModInitializer {

    private static final Map<class_1792, TooltipData> SMITHING_TEMPLATE_TOOLTIPS = new HashMap<>();
    
    // Class to hold tooltip data for each smithing template
    private static class TooltipData {
        public final String title;
        public final String location;
        public final String duplication;
        public final String usage;
        public final String lore;
        
        public TooltipData(String title, String location, String duplication, String usage, String lore) {
            this.title = title;
            this.location = location;
            this.duplication = duplication;
            this.usage = usage;
            this.lore = lore;
        }
    }
    
    @Override
    public void onInitializeClient() {
        ItemTooltipCallback.EVENT.register((stack, context, tooltipType, lines) -> {
            class_1792 item = stack.method_7909();
            
            // Only process smithing templates
            if (SMITHING_TEMPLATE_TOOLTIPS.containsKey(item)) {
                // Clear the default tooltip lines
                lines.clear();
                
                // Get tooltip data for this template
                TooltipData data = SMITHING_TEMPLATE_TOOLTIPS.get(item);
                
                // Add title (gold color)
                lines.add(class_2561.method_43470(data.title).method_10862(class_2583.field_24360.method_10977(class_124.field_1065)));
                
                // Add Found section (yellow)
                lines.add(class_2561.method_43470("Found: ").method_10862(class_2583.field_24360.method_10977(class_124.field_1054))
                        .method_10852(class_2561.method_43470(data.location).method_10862(class_2583.field_24360.method_10977(class_124.field_1068))));
                
                // Add Duplicate section (aqua) 
                lines.add(class_2561.method_43470("Duplicate: ").method_10862(class_2583.field_24360.method_10977(class_124.field_1075))
                        .method_10852(class_2561.method_43470(data.duplication).method_10862(class_2583.field_24360.method_10977(class_124.field_1068))));
                
                // Add Use section (green)
                lines.add(class_2561.method_43470("Use: ").method_10862(class_2583.field_24360.method_10977(class_124.field_1060))
                        .method_10852(class_2561.method_43470(data.usage).method_10862(class_2583.field_24360.method_10977(class_124.field_1068))));
                
                // Add Lore section (light purple with italics)
                lines.add(class_2561.method_43470("Lore: ").method_10862(class_2583.field_24360.method_10977(class_124.field_1076))
                        .method_10852(class_2561.method_43470("\"" + data.lore + "\"")
                                .method_10862(class_2583.field_24360.method_10977(class_124.field_1076).method_10978(true))));
                
                // Add Vanilla Minecraft information
                lines.add(class_2561.method_43470("Items").method_10862(class_2583.field_24360.method_10977(class_124.field_1078)));
                lines.add(class_2561.method_43470("Smithing Template"));
                lines.add(class_2561.method_43470("Applies to:"));
                lines.add(class_2561.method_43470("  Armor").method_10862(class_2583.field_24360.method_10977(class_124.field_1078)));
                lines.add(class_2561.method_43470("Ingredients:"));
                lines.add(class_2561.method_43470("  Ingots & Crystals").method_10862(class_2583.field_24360.method_10977(class_124.field_1078)));
            }
        });
        
        // Initialize all smithing template tooltips
        initializeTooltipData();
        
        ExampleMod.LOGGER.info("Smithing Template Tooltips client initialized!");
    }
    
    private void initializeTooltipData() {
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41946, new TooltipData(
            "Netherite Upgrade", 
            "Bastion remnants treasure chests", 
            "7 Diamonds + Netherrack", 
            "Use with Diamond equipment and Netherite Ingot to upgrade to Netherite", 
            "Forged in flames eternal, it carries the heat of the Nether itself."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41949, new TooltipData(
            "Coast Armor Trim", 
            "Shipwreck treasure chests", 
            "7 Diamonds + Cobblestone", 
            "Apply with Prismarine Shard for a barnacle-like nautical accent (you can use any)", 
            "Grains of sand and barnacles seem embedded in the pattern, as if drifted ashore from the deep sea."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41948, new TooltipData(
            "Dune Armor Trim", 
            "Desert pyramids", 
            "7 Diamonds + Sandstone", 
            "Apply with Gold Ingot for sandy wave-like patterns (you can use any)", 
            "Ancient windblown carvings that seem to shift like the desert itself."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41952, new TooltipData(
            "Eye Armor Trim", 
            "Stronghold libraries", 
            "7 Diamonds + End Stone", 
            "Apply with any material for mysterious watching eye patterns", 
            "The unblinking watchers of the void that never sleep, always vigilant."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_43200, new TooltipData(
            "Host Armor Trim", 
            "Trail ruins", 
            "7 Diamonds + Terracotta", 
            "Apply with any material for noble decorative accents", 
            "Echoes of lost feasts and hospitality from a forgotten civilization."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_43199, new TooltipData(
            "Raiser Armor Trim", 
            "Trail ruins", 
            "7 Diamonds + Terracotta", 
            "Apply with any material for proud, upward lifting patterns", 
            "Worn by those who built high and reached for the heavens."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41956, new TooltipData(
            "Rib Armor Trim", 
            "Nether fortress chests", 
            "7 Diamonds + Netherrack", 
            "Apply with any material for bone-like ribcage patterns", 
            "Forged from the ribs of the blaze-born, still warm to the touch."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41947, new TooltipData(
            "Sentry Armor Trim", 
            "Pillager outposts", 
            "7 Diamonds + Cobblestone", 
            "Apply with any material for vigilant, military-style markings", 
            "Eyes always watching, standing guard against the coming storm."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_43197, new TooltipData(
            "Shaper Armor Trim", 
            "Trail ruins", 
            "7 Diamonds + Terracotta", 
            "Apply with any material for intricate crafted armor detail", 
            "The hands that molded this legacy left their mark for eternity."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_43198, new TooltipData(
            "Silence Armor Trim", 
            "Ancient city loot chests", 
            "7 Diamonds + Deepslate", 
            "Apply with any material for hushed, mysterious markings", 
            "Whispers of deep time that quiet your footsteps in the darkness."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41955, new TooltipData(
            "Snout Armor Trim", 
            "Bastion remnants", 
            "7 Diamonds + Blackstone", 
            "Apply with any material for fierce tusk-like accents", 
            "Styled by brute hands, marked with the tusks of conquering warriors."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41957, new TooltipData(
            "Spire Armor Trim", 
            "End City treasure chests", 
            "7 Diamonds + Purpur", 
            "Apply with any material for elegant, arcane spire patterns", 
            "Stylized to reach the stars, it whispers secrets of the void."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41954, new TooltipData(
            "Tide Armor Trim", 
            "Ocean monument loot", 
            "7 Diamonds + Prismarine", 
            "Apply with any material for flowing wave-like patterns", 
            "It harnesses the current's grace and flows like water with every move."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41953, new TooltipData(
            "Vex Armor Trim", 
            "Woodland mansion treasure rooms", 
            "7 Diamonds + Cobblestone", 
            "Apply with any material for ethereal, ghostly patterns", 
            "Spiteful spirits endure within this pattern, their vengeance never sated."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41951, new TooltipData(
            "Ward Armor Trim", 
            "Ancient city hidden rooms", 
            "7 Diamonds + Deepslate", 
            "Apply with any material for protective warding sigils", 
            "Runes of the Deep Dark that ward against unknown terrors."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_43196, new TooltipData(
            "Wayfinder Armor Trim", 
            "Trail ruins", 
            "7 Diamonds + Terracotta", 
            "Apply with any material for explorer-themed compass patterns", 
            "Guided by ancient paths, it always leads you to adventure."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_41950, new TooltipData(
            "Wild Armor Trim", 
            "Jungle temples", 
            "7 Diamonds + Mossy Cobblestone", 
            "Apply with any material for untamed, naturalistic patterns", 
            "Tamed by no one, it grows wild like the jungle itself."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_49818, new TooltipData(
            "Bolt Armor Trim", 
            "Trial Chamber vaults (requires a Vault key)", 
            "7 Diamonds + 1 Block of Copper", 
            "Apply with Copper Ingot for a circuitry trim (you can use any)", 
            "Lightning crackles along the edges of this trim, evoking the ancient power hidden in the Vault."
        ));
        
        SMITHING_TEMPLATE_TOOLTIPS.put(class_1802.field_49817, new TooltipData(
            "Flow Armor Trim", 
            "Trail ruins", 
            "7 Diamonds + Terracotta", 
            "Apply with any material for elegant flowing water patterns", 
            "Movement preserved in time, like rivers flowing through ancient stone."
        ));
    }
}